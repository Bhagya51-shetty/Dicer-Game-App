let score1 = 0;
let score2 = 0;
let gameOver = false;
let winningScore = 10;

function rollDice(){

    if(gameOver) return;

    let dice1 = document.getElementById("dice1");
    let dice2 = document.getElementById("dice2");

    dice1.classList.add("roll");
    dice2.classList.add("roll");

    setTimeout(()=>{

        let num1 = Math.floor(Math.random() * 6) + 1;
        let num2 = Math.floor(Math.random() * 6) + 1;
        
        dice1.src = "dice" + num1 + ".png";
        dice2.src = "dice" + num2 + ".png";

        let result = "";

        if(num1 > num2) {
            score1++;
            result = "Player 1 Wins🎊";
        }else if(num2 > num1){
            score2++;
            result = "Player 2 Wins🎊";
        }else{
            result = "Draw";
        }

        document.getElementById("result").innerText = result;
        document.getElementById("score").innerText = "Score -> P1: " + score1 + " | P2: " + score2;


        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(() => {});
        }

        dice1.classList.remove("roll");
        dice2.classList.remove("roll");

    }, 400);
}

function resetGame() {
    score1 = 0;
    score2 = 0;
    gameOver = false;

    document.getElementById("score").innerText = "Score -> P1: 0 | P2: 0";
    document.getElementById("result").innerText = "Game Reset! Click Roll";

    document.getElementById("dice1").src = "dice1.png";
    document.getElementById("dice2").src = "dice1.png";
}

if(score1 === winningScore) {
    result = "🏆 Player 1 is the FINAL WINNER!";
    document.getElementById("result").classList.add("winner");
    gameOver = true;
}